// method_preserver.go
package main

import (
	"encoding/json"
	"net/http"
	"regexp"
)

func preserveMethods(code string) string {
	re := regexp.MustCompile(`(\.[a-zA-Z_]\w*)`)
	return re.ReplaceAllString(code, "_METHODPLACEHOLDER$1")
}

func restoreMethods(code string) string {
	return regexp.MustCompile(`_METHODPLACEHOLDER`).ReplaceAllString(code, "")
}

func handler(w http.ResponseWriter, r *http.Request) {
	var data map[string]string
	json.NewDecoder(r.Body).Decode(&data)

	stage := data["stage"]
	code := data["code"]
	var result string

	if stage == "preserve" {
		result = preserveMethods(code)
	} else {
		result = restoreMethods(code)
	}

	json.NewEncoder(w).Encode(map[string]string{"code": result})
}

func main() {
	http.HandleFunc("/obfuscate", handler)
	println("method_preserver running on :5005")
	http.ListenAndServe(":5005", nil)
}
