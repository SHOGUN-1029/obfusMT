package main

import (
	"encoding/json"
	"fmt"
	"math/rand"
	"net/http"
	"regexp"
)

func generateHexName() string {
	const chars = "0123456789abcdef"
	name := "_"
	for i := 0; i < 8; i++ {
		name += string(chars[rand.Intn(len(chars))])
	}
	return name
}

func aliasFunctions(code string) string {
	// Match function declarations: function foo(
	re := regexp.MustCompile(`function\s+([a-zA-Z_]\w*)\s*\(`)
	matches := re.FindAllStringSubmatch(code, -1)

	seen := make(map[string]string)

	for _, match := range matches {
		funcName := match[1]

		if _, exists := seen[funcName]; exists {
			continue
		}

		alias := generateHexName()
		seen[funcName] = alias

		// Replace function declaration
		declRe := regexp.MustCompile(fmt.Sprintf(`\bfunction\s+%s\b`, regexp.QuoteMeta(funcName)))
		code = declRe.ReplaceAllString(code, "function "+alias)

		// Replace all function calls
		callRe := regexp.MustCompile(fmt.Sprintf(`\b%s\s*\(`, regexp.QuoteMeta(funcName)))
		code = callRe.ReplaceAllString(code, alias+"(")
	}

	return code
}

func handler(w http.ResponseWriter, r *http.Request) {
	var data map[string]string
	err := json.NewDecoder(r.Body).Decode(&data)
	if err != nil {
		http.Error(w, "Invalid JSON", http.StatusBadRequest)
		return
	}

	aliased := aliasFunctions(data["code"])

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{"code": aliased})
}

func main() {
	http.HandleFunc("/obfuscate", handler)
	fmt.Println("function_aliaser running on :5004")
	http.ListenAndServe(":5004", nil)
}
