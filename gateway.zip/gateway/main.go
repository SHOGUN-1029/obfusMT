package main

import (
	"bytes"
	"encoding/json"
	"io/ioutil"
	"log"
	"net/http"
)

type RequestPayload struct {
	Code     string   `json:"code"`
	Pipeline []string `json:"pipeline"`
}

var serviceMap = map[string]string{
	"remove_comments_n_space": "http://remove_comments_n_space:5001/obfuscate",
	"var_func_name_mangling":  "http://var_func_name_mangling:5002/obfuscate",
	"string_literal":          "http://string_literal:5003/obfuscate",
	"func_pointer_alias":      "http://func_pointer_alias:5004/obfuscate",
	"preserve_method_call":    "http://preserve_method_call:5005/obfuscate",
	"base64":                  "http://base64:5006/obfuscate",
	"add_whitespace":            "http://add_whitespace:6001/obfuscate",
	"func_alias":            "http://func_alias:6004/obfuscate",
	"mangle_identifiers":            "http://mangle_identifiers:6002/obfuscate",
	"method_preserve":            "http://method_preserve:6005/obfuscate",
	"string_decode":            "http://string_decode:6003/obfuscate",
	"base64_decode":            "http://base64_decode:6006/obfuscate",	
}

func handler(w http.ResponseWriter, r *http.Request) {
	//CORS
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Methods", "POST, OPTIONS")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type")

	// Handle preflight
	if r.Method == http.MethodOptions {
		w.WriteHeader(http.StatusOK)
		return
	}
	var req RequestPayload
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid request", http.StatusBadRequest)
		return
	}
	code := req.Code

	for _, service := range req.Pipeline {
		url, ok := serviceMap[service]
		if !ok {
			http.Error(w, "Unknown service: "+service, http.StatusBadRequest)
			return
		}
		payload, _ := json.Marshal(map[string]string{"code": code})
		resp, err := http.Post(url, "application/json", bytes.NewBuffer(payload))
		if err != nil {
			http.Error(w, "Failed to reach service: "+service, http.StatusInternalServerError)
			return
		}
		body, _ := ioutil.ReadAll(resp.Body)
		var result map[string]string
		json.Unmarshal(body, &result)
		code = result["code"]
	}
	json.NewEncoder(w).Encode(map[string]string{"code": code})
}

func main() {
	http.HandleFunc("/obfuscate", handler)
	log.Println("Gateway running on :8000")
	http.ListenAndServe(":8000", nil)
}
