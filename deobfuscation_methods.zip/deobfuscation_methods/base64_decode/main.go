package main

import (
	"encoding/base64"
	"encoding/json"
	"net/http"
	"regexp"
	
)

func extractBase64(js string) string {
	// Match eval(atob("base64string")) or eval(atob('base64string'))
	re := regexp.MustCompile(`eval\s*\(\s*atob\s*\(\s*["']([^"']+)["']\s*\)\s*\)\s*;?`)
	match := re.FindStringSubmatch(js)
	if len(match) > 1 {
		return match[1] // the base64-encoded string
	}
	return ""
}

func decodeBase64JS(js string) string {
	encoded := extractBase64(js)
	if encoded == "" {
		return "// Could not find valid eval(atob(...)) pattern"
	}
	decodedBytes, err := base64.StdEncoding.DecodeString(encoded)
	if err != nil {
		return "// Failed to decode base64: " + err.Error()
	}
	return string(decodedBytes)
}

func handler(w http.ResponseWriter, r *http.Request) {
	var data map[string]string
	json.NewDecoder(r.Body).Decode(&data)
	decoded := decodeBase64JS(data["code"])
	json.NewEncoder(w).Encode(map[string]string{"code": decoded})
}

func main() {
	http.HandleFunc("/obfuscate", handler)
	println("string_decoder running on :6006")
	http.ListenAndServe(":6006", nil)
}
