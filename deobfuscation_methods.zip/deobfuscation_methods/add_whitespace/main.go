package main

import (
	"encoding/json"
	"net/http"
	"regexp"
	"strings"
)

func prettyFormat(code string) string {
	// Add newlines after semicolons and braces for readability
	code = regexp.MustCompile(`;`).ReplaceAllString(code, ";\n")
	code = regexp.MustCompile(`\{`).ReplaceAllString(code, "{\n")
	code = regexp.MustCompile(`\}`).ReplaceAllString(code, "}\n")
	// Trim excess whitespace
	return strings.TrimSpace(code)
}

func handler(w http.ResponseWriter, r *http.Request) {
	var data map[string]string
	json.NewDecoder(r.Body).Decode(&data)
	formatted := prettyFormat(data["code"])
	json.NewEncoder(w).Encode(map[string]string{"code": formatted})
}

func main() {
	http.HandleFunc("/obfuscate", handler)
	println("comment_restorer running on :6001")
	http.ListenAndServe(":6001", nil)
}
