package main

import (
	"encoding/json"
	"fmt"
	"math/rand"
	"net/http"
	"regexp"
	"strings"
	"time"
)

func mangleIdentifiers(js string) string {
	rand.Seed(time.Now().UnixNano())
	identifiers := make(map[string]string)
	re := regexp.MustCompile(`\b(var|let|const|function)\s+([a-zA-Z_]\w*)`)

	js = re.ReplaceAllStringFunc(js, func(match string) string {
		parts := strings.Fields(match)
		if len(parts) < 2 {
			return match
		}
		original := parts[1]
		if _, exists := identifiers[original]; !exists {
			obf := fmt.Sprintf("_%c%x", 'a'+rune(rand.Intn(26)), rand.Intn(9999))
			identifiers[original] = obf
		}
		return parts[0] + " " + identifiers[original]
	})

	for original, obfuscated := range identifiers {
		js = regexp.MustCompile(`\b`+regexp.QuoteMeta(original)+`\b`).ReplaceAllString(js, obfuscated)
	}
	return js
}

func handler(w http.ResponseWriter, r *http.Request) {
	var data map[string]string
	json.NewDecoder(r.Body).Decode(&data)
	cleaned := mangleIdentifiers(data["code"])
	json.NewEncoder(w).Encode(map[string]string{"code": cleaned})
}

func main() {
	http.HandleFunc("/obfuscate", handler)
	println("comment_removal running on :5002")
	http.ListenAndServe(":5002", nil)
}
