// comment_removal.go
package main

import (
	"encoding/json"
	"net/http"
	"regexp"
	"strings"
)

func removeComments(code string) string {
	singleLine := regexp.MustCompile(`//.*?\n`)
	multiLine := regexp.MustCompile(`/\*[\s\S]*?\*/`)
	code = singleLine.ReplaceAllString(code, "")
	code = multiLine.ReplaceAllString(code, "")
	return code
}

func minimizeWhitespace(code string) string {
	space := regexp.MustCompile(`\s+`)
	return strings.TrimSpace(space.ReplaceAllString(code, " "))
}

func handler(w http.ResponseWriter, r *http.Request) {
	var data map[string]string
	json.NewDecoder(r.Body).Decode(&data)
	cleaned := removeComments(data["code"])
	cleanedn := minimizeWhitespace(cleaned)
	json.NewEncoder(w).Encode(map[string]string{"code": cleanedn})
}

func main() {
	http.HandleFunc("/obfuscate", handler)
	println("comment_removal running on :5001")
	http.ListenAndServe(":5001", nil)
}
